package org.inceptez.hack
import org.apache.hadoop.hive.ql.exec.Description
import org.apache.hadoop.hive.ql.exec.UDF

class allmethods extends UDF with java.io.Serializable {
  def remspecialchar(inputString:String):String = 
  {
    var outputString:String = ""
    outputString = inputString.replaceAll("[0-9-?,/()\\[\\]]", "")//added "(" by myself
    return outputString
  }  
}

class hiveUDF extends UDF {
  def evaluate(inputString:String):String = 
  {
    var outputString:String = ""
    outputString = inputString.replaceAll("[-?,/()\\[\\]]", "")//added "(" by myself
    return outputString
  }  
}