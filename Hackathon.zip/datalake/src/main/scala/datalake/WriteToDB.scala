package datalake
import org.apache.spark.sql._
import java.util.Properties
import java.io.FileInputStream
trait WriteToDB 
{
  def writeHiveTable(df:DataFrame, TableName:String, PartitionFlag:Boolean, PartitionColumn:String): Boolean = 
  {
    if (PartitionFlag == false)
    {
      //option("temporary", IsTemporary) is not working. PLease check
      df.write.mode(SaveMode.Overwrite).saveAsTable(TableName)
      println("Data written to Hive with Parition")
    }
    else
    {
      df.write.mode(SaveMode.Overwrite).partitionBy(PartitionColumn).saveAsTable(TableName)
      println("data written to hive partition tables")
    }
    true
  }
  
  def writeRdbmsTable(df:DataFrame,DatabaseName:String, TableName:String, PartitionColumn:String,ConnectionFile:String,WriteMode:String):Boolean = 
  {
      val connection     =  new Properties()
      val prepertyFile   =  new FileInputStream(s"$ConnectionFile")
      connection.load(prepertyFile) 
      
      val Driver         =  connection.getProperty("driver")
      val Host           =  connection.getProperty("host")
      val Port           =  connection.getProperty("port")
      val User           =  connection.getProperty("user")
      val Password       =  connection.getProperty("password")
      val Dbtype         =  connection.getProperty("dbtype")
      val URL            =  Dbtype+Host+":"+Port+"/"+s"$DatabaseName"
     
      println("URL: " + URL)
      
      val properties = new Properties()
      properties.put("user", s"$User")
      properties.put("password", s"$Password")
      properties.put("driver",s"$Driver")
      println("WriteMode: " + WriteMode)
      df.write.mode(WriteMode).jdbc(s"$URL",s"$TableName",properties)
      println("Data Written to RDBMS")
            
      true
  }
  
  def writeFile(df:DataFrame, FileFormat:String, Location:String, PartitionFlag:Boolean,PartitionColumn:String):Boolean = 
  {
    if (PartitionFlag == false)
    {
      if (FileFormat.toUpperCase() == "JSON")
      {
        df.write.mode(SaveMode.Overwrite).json(Location)        
      }
      else if (FileFormat.toUpperCase() == "CSV")
      {
        df.write.mode(SaveMode.Overwrite).option("header","true").csv(Location)
      }
    }
    else
    {
      if (FileFormat.toUpperCase() == "JSON")
      {
        df.write.mode(SaveMode.Overwrite).partitionBy(PartitionColumn).json(Location)        
      }
      else if (FileFormat.toUpperCase() == "CSV")
      {
        df.write.mode(SaveMode.Overwrite).partitionBy(PartitionColumn).option("header","true").csv(Location)
      }
    }  
    println(FileFormat.toUpperCase() + " data written into " + Location)
    true
  }
  
  def writeTeCassandra(df:DataFrame, TableName:String, Keyspace:String):Boolean =
  {
    df.write.mode(SaveMode.Append).format("org.apache.spark.sql.cassandra").options(Map("table" -> TableName, "keyspace" -> Keyspace)).save()
    true
  }
}