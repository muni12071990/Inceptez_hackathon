package datalake

import org.apache.spark.sql.SparkSession
import java.util.Properties
import java.io.FileInputStream
import org.apache.hadoop.hive.ql.metadata.Hive
import org.apache.spark.sql.functions._


object dl_main_object extends GetPutDataTrait with WriteToDB {
  def main(args:Array[String])
  {
    """
before starting the execution daily

  MYSQL: update spark_datalake_pjt.employees set upddt=current_date;
  Hive: drop database retailstaging cascade;
        drop database retailcurated cascade;
        drop database retaildiscovery cascade;
  Linux: hadoop fs -rmr /user/hduser/projects/project3
  
  Try to write the process with try catch block after finishing cassandra writting
"""
    
    val sparksession = SparkSession.builder().appName("Spark Datalake").master("local[*]").
                       config("spark.eventLog.dir","file:///tmp/spark-events").
                       config("spark.history.fs.logDirectory","file:///tmp/spark-events").
                       config("spark.eventLog.enabled","true").
                       config("hive.metastore.uris","thrift://127.0.0.1:9083").
                       config("spark.sql.warehouse.dir","hdfs://127.0.0.1:54310/user/hive/warehouse").
                       config("spark.sql.shuffle.partitions",10).
                       config("spark.sql.crossJoin.enabled","true").
                       enableHiveSupport().getOrCreate();
    
    val sc = sparksession.sparkContext;
    val sqlc = sparksession.sqlContext
    sc.setLogLevel("ERROR")
    println(sparksession)
    
    // getting the location of the property file
    val connectionFile = "/home/hduser/projects/project3/retailordersspark/connection.prop"
    
    val connection     =  new Properties()
    val prepertyFile   =  new FileInputStream(s"$connectionFile")
    connection.load(prepertyFile)
    
    val hdfsUri = connection.getProperty("hdfsuri")
    
    val dummyUpperBound = 1
    // Arguemts are passed to main method only for this set and rest all are hard coded
    //"employees" "upddt" "spark_datalake_pjt" "employeeNumber" "true"
    val table_name = args(0) //employees
    val col_name = args(1) // upddt
    val db_name = args(2) // spark_datalake_pjt
    val partitionColumn = args(3) //employeeNumber
    val PartitionFlag = args(4).toBoolean
    val customQuery = s"(select * from $db_name.$table_name where $col_name > current_date - interval 1 day) tempTable"
    println("customQuery: " + customQuery)
    // def getRdbmsData(sqlc:SQLContext, DatabaseName:String, TableName:String, PartitionColumn:String,ConnectionFile:String,UpperBound:Long,PartitionFlag:Boolean):DataFrame 
    val getEmpData = getRdbmsData(sqlc,db_name,customQuery,partitionColumn,connectionFile,dummyUpperBound.toLong,PartitionFlag)
    getEmpData.createOrReplaceTempView("EmpData")
    println("Employee data successfully pulled from Mysql!!!" )
    getEmpData.show(2, false)
    
    // using overloaded method
    val getOfficeData = getRdbmsData(sqlc,db_name,"offices",connectionFile)
    getOfficeData.createOrReplaceTempView("OfficeData")
    println("offices data successfully pulled from Mysql!!!" )
    getOfficeData.show(2,false)
    
    // Hive functions start here
    sparksession.sql("create database if not exists retailstaging")
    sparksession.sql("use retailstaging")
    
    // def writeHiveTable(df:DataFrame, TableName:String, PartitionFlag:Boolean, PartitionColumn:String): Boolean
    // SaveMode is set as Overwrite and so always exiting able will be dropped and recreated
    val loadEmployeeFlag = writeHiveTable(getEmpData,"retailstaging.EmpData",true,"employeeNumber")
    val loadOfficeFlag = writeHiveTable(getOfficeData, "retailstaging.OfficeData", false, null)
    
    if (loadEmployeeFlag == true && loadOfficeFlag == true)
    {
      println("retailstaging.EmpData and retailstaging.OfficeData Hive tables created successful")
    }
    """
    //trying to create a managed temp table in HIVE staging layer
    sparksession.sql("create temporary table retailstaging.EmpData as select * from EmpData")
    sparksession.sql("select * from retailstaging.EmpData limit 10").show(false)
    
    Exception in thread "main" org.apache.spark.sql.catalyst.parser.ParseException: 
    CREATE TEMPORARY TABLE is not supported yet. Please use CREATE TEMPORARY VIEW as an alternative.(line 1, pos 0)    
    """
    
    // creating an UDF for concat function
    val cleanup = new datalake.reusableFunctions // object creation for the class
    val udf_concate = udf(cleanup.udf_concat _) // registering as an UDF function
    
    //framing payments query
    val custPaymentsQuery = """(select c.customerNumber, upper(c.customerName) upperCustName,c.contactFirstName,c.contactLastName,c.phone,c.addressLine1,
    c.city,c.state,c.postalCode,c.country ,c.salesRepEmployeeNumber,c.creditLimit ,p.checknumber,p.paymentdate,p.amount from customers c 
    inner join payments p on c.customernumber=p.customernumber and year(p.paymentdate)=2020 and month(p.paymentdate)=10) custPaymentsQuery"""
    
       
    val orderDetailsQuery = """(select
    o.customernumber,o.ordernumber,o.orderdate,o.shippeddate,o.status,o.comments,od.productcode productcode,od.quantityordered,od.priceeach,
    od.orderlinenumber,p.productCode productcode_01,p.productName,p.productLine,p.productScale,p.productVendor,p.productDescription,p.quantityInStock,
    p.buyPrice,p.MSRP from orders o inner join orderdetails od on o.ordernumber=od.ordernumber inner join products p on 
    od.productCode=p.productCode and year(o.orderdate)=2020 and month(o.orderdate)=10) orderDetailsQuery"""
    
    val paymentsDetails = getRdbmsData(sqlc, "spark_datalake_pjt", custPaymentsQuery, connectionFile)
    println("**********************")
    // using udf_concate in the DSL query
    println("printing name of customer 103 using UDF from DSL")
    paymentsDetails.select(udf_concate(col("contactFirstName"), col("contactLastName"))).where("customernumber = 103").show(false)
    println("**********************")
    paymentsDetails.createOrReplaceTempView("paymentsDetails")
    paymentsDetails.show(2, false)
    
    
    //partition with productLine will be apt
    //Exception in thread "main" org.apache.spark.sql.AnalysisException: Partition column type should be numeric, date, or timestamp, but string found.;
    //So putting the partition column as numeric
    //val orderDetails = getRdbmsData(sqlc, "spark_datalake_pjt", orderDetailsQuery, connectionFile)
    val orderDetails = getRdbmsData(sqlc, "spark_datalake_pjt", orderDetailsQuery, "customernumber", connectionFile, dummyUpperBound.toLong, true)
    println("Number of partitions: " + orderDetails.rdd.getNumPartitions)
    orderDetails.createOrReplaceTempView("orderDetails")
    orderDetails.show(2, false)
    
    //writing the order and payments details into HIVE
    val paymentsDetailsFlag = writeHiveTable(paymentsDetails, "retailstaging.paymentsDetails", false, null)
    //val orderDetailsFlag = writeHiveTable(orderDetails, "retailstaging.orderDetails", false, null)
    val orderDetailsFlag = writeHiveTable(orderDetails, "retailstaging.orderDetails", true, "customernumber")
    
    if (paymentsDetailsFlag == true && orderDetailsFlag == true)
    {
      sparksession.sql("select count(1) from retailstaging.paymentsDetails").show(false)
      sparksession.sql("describe retailstaging.orderDetails").show(100,false)
    }
    //data got stored into retailstaging database in HIVE
    """
    hive> show tables;
    OK
    empdata
    empdata_tmp
    officedata
    orderdetails
    paymentsdetails
    Time taken: 0.073 seconds, Fetched: 5 row(s)  
    """
    ///////////////////////////////////////////////////////////
    //Starting to create the retailcurated DB in HIVE to store the curated data from staging layer
    // 'Created On' = cast(current_date() as string) throwing error in HIVE
    sparksession.sql("create database if not exists retailcurated comment 'To store the curated data to load into final mart' with dbproperties('Created By' = 'Muniappan')")
    
    sparksession.sql("""create table if not exists retailcurated.customerdetails(
      customernumber int, customername varchar(100), contactfullname varchar(200), 
      address struct<addressline1:varchar(100), addressline2:varchar(100), addressline3:varchar(100), city:varchar(50), state:varchar(10),
      zip:bigint>, country varchar(10), phone bigint, creditlimit float, checknumber varchar(25), checkamount float, paymentdate date)
      row format delimited fields terminated by '~'
      stored as textfile""")
      
      """
      Direct Hive select of retailstaging.paymentsdetails throws error as Spark saved it in Parquet format  
      """
            
      sparksession.udf.register("udf_concate", udf_concate) // registering UDF to be used in SQLs
      
      sparksession.sql("""insert overwrite table retailcurated.customerdetails
        select customernumber, uppercustname, udf_concate(contactfirstname,contactlastname),
        named_struct('addressline1',addressline1, 'addressline2',addressline1, 'addressline3',addressline1, 'city',city, 
        'state', state, 'zip',postalcode), country, phone, creditlimit,
        checknumber, amount, paymentdate
        from retailstaging.paymentsdetails""")
        sparksession.sql("select * from retailcurated.customerdetails").show(2, false)
        
     //Starting the process to write the curated data into external table into a different HDFS location
     // enabling the dynamic partition true as we're trying to load data dynamically
     """
     Exception in thread "main" org.apache.spark.sql.AnalysisException: Output Hive table `retailcurated`.`cust_ext_payment_details` is bucketed 
     but Spark currently does NOT populate bucketed output which is compatible with Hive.;  
     
     So removing the "clustered by (country) into 4 buckets" clause from retailcurated.cust_ext_payment_details creation
     """
     sparksession.sql("set hive.enforce.bucketing = true")   
     sqlc.setConf("hive.enforce.bucketing", "true")
     
     sparksession.sql("set hive.exec.dynamic.partition = true")
     sqlc.setConf("hive.exec,dynamic.partition", "true")
     
     sparksession.sql("set hive.exec.dynamic.partition.mode = nonstrict")
     sqlc.setConf("hive.exec,dynamic.partition.mode", "nonstrict")
     
     sparksession.sql("""create external table if not exists retailcurated.cust_ext_payment_details(
       customernumber int, customername varchar(100), contactfullname varchar(200), 
      address struct<addressline1:varchar(100), addressline2:varchar(100), addressline3:varchar(100), city:varchar(50), state:varchar(10), zip:bigint>, 
      country varchar(10), phone bigint, creditlimit float, checknumber varchar(25), checkamount float)
      partitioned by (paymentdate date)
      row format delimited fields terminated by '~' collection items terminated by '$' 
      stored as textfile
      location 'hdfs:///user/hduser/projects/project3/retailcurated_cust_ext_payment_details'""")
     
    sparksession.sql("""insert overwrite table retailcurated.cust_ext_payment_details partition (paymentdate)
	  select customernumber, customername, contactfullname, address, country, phone, creditlimit, checknumber, checkamount, paymentdate
	   from retailcurated.customerdetails""")  
	   
	  sparksession.sql("describe retailcurated.cust_ext_payment_details").show(100, false) 
	  
	  sparksession.sql("""create external table if not exists retailcurated.orders_ext_details(
	    customernumber int, ordernumber int, shippeddate date,status varchar(50), comments varchar(500),productcode varchar(50),quantityordered int,priceeach decimal(10,2),orderlinenumber int,
      productName varchar(50),productLine varchar(50), productScale varchar(50),productVendor varchar(50),productDescription varchar(500),quantityInStock int,buyPrice decimal(10,2),
      MSRP decimal(10,2)) partitioned by (orderdate date)
      row format delimited fields terminated by '~'
      stored as textfile location 'hdfs:///user/hduser/projects/project3/retailcurated_orders_ext_details'""")
      
     sparksession.sql("""insert into retailcurated.orders_ext_details partition(orderdate)
       select customernumber,ordernumber, shippeddate,status,comments,productcode,quantityordered ,priceeach ,orderlinenumber ,productName
      ,productLine,productScale,productVendor,productDescription,quantityInStock,buyPrice,MSRP,orderdate
      from retailstaging.orderDetails""") 
      
     val orders_ext_details = sparksession.sql("select * from retailcurated.orders_ext_details")
     """
      Parition calculation is important and its derivation is to be studied.
      
      orders_ext_details.rdd.getNumPartitions: 111
      ***************************
      When the staging table and curated base table is not partitioned, then orders_ext_details.rdd.getNumPartitions: 31
      """
     println("orders_ext_details.rdd.getNumPartitions: " + orders_ext_details.rdd.getNumPartitions)
     
     // Porting the data to discovery layer
     sparksession.sql("create database if not exists retaildiscovery with dbproperties('Created By' = 'Muniappan')")
     
     // Dimensions data load
     sparksession.sql("""create external table if not exists retaildiscovery.dim_order_rate 
       (rid int,orddesc varchar(200),comp_cust varchar(10),siverity int, intent varchar(100))
        row format delimited fields terminated by ','
        location 'hdfs:///user/hduser/projects/project3/retaildiscovery_dimorders'""")
        
     sparksession.sql("load data local inpath '/home/hduser/projects/project3/retailordersspark/data/orders_rate.csv' overwrite into table retaildiscovery.dim_order_rate")
     
     sparksession.sql("select count(*) from retaildiscovery.dim_order_rate").show(false)
     
     sparksession.sql("""create table if not exists retailstaging.cust_navigation (customernumber varchar(100),comments varchar(500),
       pagenavigation array<varchar(100)>,pagenavigationidx array <int>)
        row format delimited fields terminated by ',' 
        collection items terminated by '$'""")
     
     sparksession.sql("load data local inpath '/home/hduser/projects/project3/retailordersspark/data/cust_visits.csv' overwrite into table retailstaging.cust_navigation")
     
     sparksession.sql("select count(*) from retailstaging.cust_navigation").show(false)
     
     sparksession.sql("""create external table if not exists retaildiscovery.cust_navigation (customernumber string,navigation_index int,navigation_pg string)
        stored as orc location 'hdfs:///user/hduser/projects/project3/cust_navigation/'""")
        """
        sample: 495	Check on availability.	["home","about-us","profile","cart","order","exit"]	[1,2,3,4,5,6]  of retailstaging.cust_navigation
        
        pagenavigation array is splitted with "," and each entry is assigned a number starting with 0
        """
     sparksession.sql("""insert into table retaildiscovery.cust_navigation select customernumber,pgnavigationidx,pgnavigation
      from retailstaging.cust_navigation lateral view posexplode(pagenavigation) exploded_data1 as pgnavigationidx,pgnavigation""")
    
      println("What is the First and last page visited and the count of visits.")
      
      val first_and_last_page = sparksession.sql("""select customernumber, min(navigation_index), max(navigation_index) from retaildiscovery.cust_navigation group by customernumber""")
      
      //coalesce is given to combine all the partitions of the data frames (i.e RDD)
      writeFile(first_and_last_page.coalesce(1), "JSON", s"$hdfsUri/user/hduser/projects/project3/first_and_last_page", false, "")
      
      // Using Irfan's code for the frustration level
      
      sparksession.sql("""create external table if not exists retaildiscovery.cust_frustration_level 
      (customernumber string,total_siverity int,frustration_level string) 
      row format delimited fields terminated by ',' location 'hdfs:///user/hduser/projects/project3/custmartfrustration/'""")
      
      // crossJoin is enabled at sparksession creation itself
      
      val frustrateddf = sparksession.sql(""" select customernumber,total_siverity,
        case when total_siverity between -10 and -3 then 'highly frustrated' 
             when total_siverity between -2 and -1 then 'low frustrated' 
             when total_siverity = 0 then 'neutral' 
             when total_siverity between 1 and 2 then 'happy' 
             when total_siverity between 3 and 10 then 'overwhelming' 
             else 'unknown' 
        end as customer_frustration_level from 
          ( select customernumber,sum(siverity) as total_siverity from 
          ( select o.customernumber,o.comments,r.orddesc,siverity 
          from retailstaging.cust_navigation o left outer join retaildiscovery.dim_order_rate r  
          where o.comments like concat('%',r.orddesc,'%')) temp1 
        group by customernumber) temp2""")
        
        frustrateddf.createOrReplaceTempView("Frustration_view")
        sparksession.sql("insert overwrite table retaildiscovery.cust_frustration_level select * from Frustration_view")
        
        //PartitionColumn of writeRdbmsTable method is not used insidid the method. Find how to create a partition table in mysql
        val tableWriteFlag = writeRdbmsTable(frustrateddf, "spark_datalake_pjt", "Frustration_table", "total_siverity", s"$connectionFile", "overwrite")
        if (tableWriteFlag == true)
        {
          println("spark_datalake_pjt.Frustration_table is created an populated in MYSQL DB")
        }
   """
     cd /usr/local/cassandra/bin
   cpid=`jps | grep Cassandra | awk -F' ' '{print $1}'`
    kill -9 $cpid

  echo "starting cassandra"
  ./cassandra  
  
   ./cqlsh
   
   create keyspace retail WITH replication = {'class':'SimpleStrategy','replication_factor':1};
cqlsh> use retail;
cqlsh:retail> create table customer_frustration_level (customernumber text primary key,total_siverity varint,customer_frustration_level text);
   """        
    
    val writeCassandraFlag = writeTeCassandra(frustrateddf, "customer_frustration_level", "retail")
    if (writeCassandraFlag == true)
    {
      println("frustrateddf data got appended to Cassandra")
    }
    
  }
}