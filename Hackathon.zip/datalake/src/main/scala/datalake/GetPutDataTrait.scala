package datalake

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql._
import java.util.Properties
import java.io.FileInputStream

trait GetPutDataTrait 
{
  def getRdbmsData(sqlc:SQLContext, DatabaseName:String, TableName:String, PartitionColumn:String,ConnectionFile:String,
                  UpperBound:Long,PartitionFlag:Boolean):DataFrame = 
  {
     val connection     =  new Properties()
     val prepertyFile   =  new FileInputStream(s"$ConnectionFile")
     connection.load(prepertyFile)
     
     val Driver         =  connection.getProperty("driver")
     val Host           =  connection.getProperty("host")
     val Port           =  connection.getProperty("port")
     val User           =  connection.getProperty("user")
     val Password       =  connection.getProperty("password")
     val Dbtype         =  connection.getProperty("dbtype")
     val URL            =  Dbtype+Host+":"+Port+"/"+s"$DatabaseName"
     
     println("getRdbmsData: URL: " + URL)
     println("getRdbmsData: $PartitionFlag: " + s"$PartitionFlag")
     //if (s"$PartitionFlag" == true) -- this option not working
     if (PartitionFlag == true)
     {
       println("getRdbmsData: Into true: $PartitionFlag: " + s"$PartitionFlag")
        val customBoundaryQuery = "(select min("+s"$PartitionColumn"+"), max("+s"$PartitionColumn"+") from "+s"$TableName"+") innerQuery"
        println("getRdbmsData: customBoundaryQuery: " + customBoundaryQuery)
        """
        mysql> select * from (select min(employeeNumber), max(employeeNumber) from (select * from employees where upddt > current_date - interval 1 day) tempTable) innerQuery;
        +---------------------+---------------------+
        | min(employeeNumber) | max(employeeNumber) |
        +---------------------+---------------------+
        |                1002 |                1702 |
        +---------------------+---------------------+
        1 row in set (0.29 sec)  
        """
        val dbcustomValues = sqlc.read.format("jdbc").
                             option("driver",Driver).
                             option("url",URL).
                             option("user",User).
                             option("dbtable",customBoundaryQuery).
                             option("password",Password).                             
                             load()
         dbcustomValues.show(false)
         
         println("Boundary query comlpeted: "+dbcustomValues.count())
         
         import sqlc.implicits._
         
         val (lowerBound, upperBound) = dbcustomValues.as[(String, String)].first()
         
         if (lowerBound == null || upperBound == null)
         {
           println("***Attention: update statement is not executed*****")
           throw new Exception()
         }
       
       """
       Exception in thread "main" org.apache.spark.sql.AnalysisException: Partition column type should be numeric, date, or timestamp, but string found.;  
       So putting the partition column as numeric
       var numberOfPartition:Long = 0
        if (upperBound.toUpperCase() == upperBound)
        {
          numberOfPartition = (upperBound.toLong/100) + 1
        }
        else
        {  
          val numPartQuery = s"(select count(1) from (select count(1) from $TableName group by productLine) tempQuery) temp"
          println(numPartQuery)
          val numberOfPartition_df = sqlc.read.format("jdbc").
                             option("driver",Driver).
                             option("url",URL).
                             option("user",User).
                             option("dbtable",numPartQuery).
                             option("password",Password).                             
                             load()
          numberOfPartition = numberOfPartition_df.as[(Long)].first()                   
        }    
        //val numberOfPartition = 10
        """
        
        val numberOfPartition = (upperBound.toLong/100) + 1
        println("Lower: " + lowerBound + ", upperBound: " + upperBound + ", numberOfPartition: " + numberOfPartition + " for table " + TableName)
        
        sqlc.read.format("jdbc").
                             option("driver",s"$Driver").
                             option("url",s"$URL").
                             option("user",s"$User").
                             option("password",s"$Password").
                             option("lowerBound",s"$lowerBound").
                             option("upperBound",s"$upperBound").
                             option("numPartitions",s"$numberOfPartition").
                             option("dbtable",s"$TableName").
                             option("partitionColumn",s"$PartitionColumn").load()
     }
     else
     {
       println("getRdbmsData: Into FALSE: $PartitionFlag: " + s"$PartitionFlag")
       sqlc.read.format("jdbc").
                             option("driver",s"$Driver").
                             option("url",s"$URL").
                             option("user",s"$User").
                             option("password",s"$Password").
                             option("dbtable",s"$TableName").load()
     }                       
  }
  
  // overloading this method 
  def getRdbmsData(sqlc:SQLContext, DatabaseName:String, TableName:String, ConnectionFile:String):DataFrame = 
  {
     val connection     =  new Properties()
     val prepertyFile   =  new FileInputStream(s"$ConnectionFile")
     connection.load(prepertyFile)
     
     val Driver         =  connection.getProperty("driver")
     val Host           =  connection.getProperty("host")
     val Port           =  connection.getProperty("port")
     val User           =  connection.getProperty("user")
     val Password       =  connection.getProperty("password")
     val Dbtype         =  connection.getProperty("dbtype")
     val URL            =  Dbtype+Host+":"+Port+"/"+s"$DatabaseName"
     
     println("getRdbmsData: URL: " + URL)
     sqlc.read.format("jdbc").
                             option("driver",s"$Driver").
                             option("url",s"$URL").
                             option("user",s"$User").
                             option("password",s"$Password").
                             option("dbtable",s"$TableName").load()                     
  }
}