package hackathon
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SparkSession
import datalake.WriteToDB

// this case class can also be given in the reUsable class
case class insureInfo1(IssuerId:Long,	IssuerId2:Long,	BusinessDate:String,	StateCode:String,	SourceName:String,	NetworkName:String,
                       NetworkURL:String,	custnum:Int,	MarketCoverage:String,	DentalOnlyPlan:String)

object mainObject extends WriteToDB{//WriteToDB trait of datalake pjt is extended to achive functionalities
  def main(args:Array[String])
  {
    val sparksession = SparkSession.builder().appName("Inceptez Hackathon").master("local[*]").
                       config("spark.eventLog.dir","file:///tmp/spark-events").
                       config("spark.history.fs.logDirectory","file:///tmp/spark-events").
                       config("spark.eventLog.enabled","true").
                       config("hive.metastore.uris",args(5)).//"thrift://127.0.0.1:9083").
                       config("spark.sql.warehouse.dir",args(6)).//"hdfs://127.0.0.1:54310/user/hive/warehouse").
                       //config("spark.sql.shuffle.partitions",10).
                       config("spark.sql.crossJoin.enabled","true").
                       enableHiveSupport().getOrCreate();
    //val conf = new SparkConf().setMaster("local[*]").setAppName("Inceptez Hackathon") //local[2] was slow after some steps
    val sc = sparksession.sparkContext
    try
    {
      sc.setLogLevel("ERROR")
      //1. Load the file1 (insuranceinfo1.csv) from HDFS using textFile API into an RDD insuredata
      //sparkCore.rddcreation
      val reUsableObj = new reUsable
      //args(0) = "hdfs://127.0.0.1:54310/user/hduser/hackathon/insuranceinfo1.csv"
      val insure1RDD = reUsableObj.rddFrompath(sc,args(0))
      //println(insure1RDD.count())
      
      """2. Remove the header line from the RDD contains column names.
          Hint: Use first and filter functions to achieve this by filtering the first line identified .
      """
      //header line is known - method 1
      //val insure1RDD_head = insure1RDD.map(x=>x.split(",")).filter(x=>x(0).toUpperCase() != "ISSUERID")
      //println("insure1RDD_head count: " + insure1RDD_head.count)
      //without knowing the header structure but know that 1st line is header -- mwthod 2
      val headerLine = insure1RDD.first()
      """    
      //println(headerLine)
      val headerRDD = insure1RDD.filter(x=>x.contains(headerLine))
      val insure1RDD_Inter = insure1RDD.subtract(headerRDD)
      //println("insure1RDDFinal count: " + insure1RDDFinal.count())
      """
      val insure1RDD_01 = insure1RDD.filter(x => x != headerLine)
      //println("insure1RDD_01 count: " + insure1RDD_01.count())
      
      """
      3. Remove the Footer/trailer also which contains “footer count is 404”
      Hint: Use functions like zipWithIndex, count and filter to remove the footer or 
      use just filter to remove if you can't implement in the above way.  
      """
      //In insure1RDDFinal RDD, the footer row is present inbetween other rows as we got it as a result of subtraction from 2 RDDs
      //insure1RDD_01.count() is stored as a separate variable rddCount as insure1RDD_01.count() count be performed inside the collect method 
      val rddCount = insure1RDD_01.count()
      val insure1RDD_01_footer = insure1RDD_01.zipWithIndex().collect{ case(i, index) if index == rddCount - 1 => i }
      //insure1RDD_01_footer.foreach(println)
      val footer = insure1RDD_01_footer.first()
      //println(footer)
      val insure1RDD_02 = insure1RDD_01.filter(x => x != footer)
      
      """
      4. Display the count and show few rows and check whether header and footer is removed.  
      """
      //println("insure1RDD_02 count without footer: " + insure1RDD_02.count())
      //insure1RDD_02.foreach(println)
      
      """
      5. Remove the blank lines in the rdd. Hint: Before splitting, trim it, calculate the length and filter only row size is not = 0.  
      """
      val insure1RDD_03 = insure1RDD_02.map(x => x.trim()).filter(x => x.length() != 0)
      //println(insure1RDD_03.count)
      
      """
      6. Map and split using ‘,’ delimiter.
  Hint: To avoid getting incomplete rows truncated, use split(“,”,-1) instead of split(“,”)
  For Eg:
  If you take the rdd.first it should show the output like the below
  Array(21989, 21989, 2019-10-01, AK, HIOS, ODS Premier, https://www.modahealth.com/ProviderSearch/faces/webpages/home.xhtml?dn=ods, 13, "", "")
  Output should not be like given below
  Array(21989, 21989, 2019-10-01, AK, HIOS, ODS Premier, https://www.modahealth.com/ProviderSearch/faces/webpages/home.xhtml?dn=ods, 13)
  
    Data:
    IssuerId,IssuerId2,BusinessDate,StateCode,SourceName,NetworkName,NetworkURL,custnum,MarketCoverage,DentalOnlyPlan
    21989,21989,2019-10-01,AK,HIOS,ODS Premier,https://www.modahealth.com/ProviderSearch/faces/webpages/home.xhtml?dn=ods,13,,
    219,219,2019-10-01,AK,HIOS,ODS Premier  
    
    Filtering only the data with 10 columns to accomodate it into a case class
      """
     
      val insure1RDD_04 = insure1RDD_03.map(x => x.split(",", -1))
      val insure1RDD_04_with_case_class = insure1RDD_04.filter(x => x.length == 10).
      map(x => insureInfo1(x(0).toInt, x(1).toInt, reUsableObj.dateReplace(x(2)), x(3), x(4), x(5), x(6), x(7).toInt,x(8), x(9)))
      //insure1RDD_04_with_case_class.foreach(println)
      
      """
      7. Filter number of fields are equal to 10 columns only - analyze why we are doing this and provide your view here.
      
      8. Add case class namely insureclass with the field names used as per the header record in the file and apply 
      to the above data to create schemaed RDD.
      
      insure1RDD_04_with_case_class cotains the data with 10 column records and case class.
      this is used to get the complete records and case class will be use when it is converted into a DF
      """
      
      """
      9. Take the count of the RDD created in step 7 and step 1 and print how many rows are removed/rejected in the 
      cleanup process of removing fields does not equals 10.  
      """
      val insure1RDD_04_with_10_cols = insure1RDD_04.filter(x => x.length == 10)
      //println(insure1RDD_04_with_10_cols.count())
      
      //println("# of rejected records: " + insure1RDD_03.map(x => x.split(",",-1)).count()
      //    + "~" + (insure1RDD_03.map(x => x.split(",",-1)).count() - insure1RDD_04_with_10_cols.count()))
          
      """
      
      
      RDD(Array(String)) is not working as expected for SET operator
      """
              
      val rejectRDD = insure1RDD_03.subtract(insure1RDD_04_with_10_cols.map(x => x.mkString(",")))
      //rejectRDD.foreach(println)
      // 219,219,2019-10-01,AK,HIOS,ODS Premier    
      // Get the rejected record?
      
      """
      10. Create another RDD namely rejectdata and store the row that does not equals 10 columns. 
      With a new column added in the first column called numcols contains number of columns in the given row 
      For eg - the output should be like this: (6,219) where 6 is the number of columns and 219 is the first column 
      IssuerId of the data hence we can analyse the IssuerIds contains deficient fields.  
      """
      val rejectedData = insure1RDD_03.map(x => x.split(",",-1)).filter(x => x.length != 10)
      //println(rejectedData.count())
      val rejectedDataAnalyze = rejectedData.map(x => {val rowCount = x.length
        (rowCount,x(0))}) // (6,219)
      //rejectedDataAnalyze.foreach(println)
        
      """
      11. Load the file2 (insuranceinfo2.csv) from HDFS using textFile API into an RDD insuredata2  
      12. Repeat from step 2 to 8 for this file also and create the schemaed rdd from the insuranceinfo2.csv and 
      filter the records that contains blank or null IssuerId,IssuerId2 for eg: remove the records with pattern given below.
      ,,,,,,,13,Individual,Yes
      """  
      //args(1) = "hdfs://127.0.0.1:54310/user/hduser/hackathon/insuranceinfo2.csv"  
      val insure2RDD = reUsableObj.rddFrompath(sc,args(1))    
      val insure2RDD_01 = insure2RDD.filter(x => x != headerLine) // both files have same header line
      val insure2RDD_01_count = insure2RDD_01.count()
      val insure2RDD_01_footer = insure2RDD_01.zipWithUniqueId().collect{case(b, index) if index == insure2RDD_01_count - 1 => b}
      val footer2 = insure2RDD_01_footer.first()
      val insure2RDD_02 = insure2RDD_01.filter(x => x != footer2)
      val insure2RDD_03 = insure2RDD_02.map(x => x.trim()).filter(x => x.length() != 0)
      val insure2RDD_04 = insure2RDD_03.map(x => x.split(",", -1))
      //println("insure2RDD_04.count: " + insure2RDD_04.count())
      val insure2RDD_04_with_case_class = insure2RDD_04.filter(x => x.length == 10).
      map(x => insureInfo1(x(0).toInt, x(1).toInt, reUsableObj.dateReplace(x(2)), x(3), x(4), x(5), x(6), x(7).toInt,x(8), x(9)))
      val insure2RDD_05 = insure2RDD_04.filter(x => {x(0).trim().length() != 0||x(1).trim().length() != 0})//filter the records that contains blank or null IssuerId,IssuerId2
      //println("insure2RDD_05.count: " + insure2RDD_05.count())
      val reject2RDD = insure2RDD_03.subtract(insure2RDD_05.map(x => x.mkString(",")))
      //reject2RDD.foreach(println)
      
      """
      13. Merge the both header and footer removed RDDs derived in steps 8 and 12 into an RDD namely insuredatamerged  
      """
      //set operators work with RDD[String]
      //println("insure2RDD_04: " + insure2RDD_04.filter(x => x.length == 10).count)
      //println("insure1RDD_04: " + insure1RDD_04.filter(x => x.length == 10).count)
      val insure1RDD_05 = insure1RDD_04.filter(x => x.length == 10)
      println("without case class")
      val insureDataMergedRDD_without_case_class = insure2RDD_05.union(insure1RDD_05)
      val insureDataMergedRDD = insure2RDD_05.union(insure1RDD_05).//distinct(). -- distinct addition will remove the duplicates here itself
      map(x => insureInfo1(x(0).toInt, x(1).toInt, reUsableObj.dateReplace(x(2)), x(3), x(4), x(5), x(6), x(7).toInt,x(8), x(9)))
      //println("insureDataMergedRDD.count: " + insureDataMergedRDD.count())
      
      // 14. Persist the step 13 RDD to memory by serializing.
      insureDataMergedRDD.persist()
      //insureDataMergedRDD.foreach(println)
      
      insureDataMergedRDD.map(x => x.BusinessDate).distinct().foreach(println)
      //01-10-2019, 2019-10-01, 02-10-2019 - There are 2 different date formats in the 2 CSV files
      // Should rearrange them to get all to the same format
      //insureDataMergedRDD.filter(x => !x.BusinessDate.substring(0,4).contains("-")).
      //map(x => x.BusinessDate.substring(8,10)+"-"+x.BusinessDate.substring(5,7)+"-"+x.BusinessDate.substring(0,4)).foreach(println)
      
      // 15. Calculate the count of rdds created in step 8+12 and rdd in step 13, check whether they are matching.
      // Manual calculation?
      if (insureDataMergedRDD.count() == (insure1RDD_05.count() + insure2RDD_05.count()))
        println("Counts match")
      
      // 16. Remove duplicates from this merged RDD created in step 13 and print how many duplicate rows are there
      // Union would've already removed duplicates between the 2 different RDDs
      // but here duplicate is in data 1 (insuredatafile01.csv)
      //val duplicateRecords = insure1RDD_01.intersection(insure2RDD_01) 
        //insure1RDD_05.map(x => x.mkString(",")).intersection(insure2RDD_05.map(x => x.mkString(",")))
      val insureDataMergedRDD_without_case_class_array = insureDataMergedRDD_without_case_class.map(x => x.mkString(","))
      val insureDataMergedRDD_distinct = insureDataMergedRDD_without_case_class.map(x => x.mkString(",")).distinct()
      println("Printing duplicates: insureDataMergedRDD_without_case_class_array.count: " + insureDataMergedRDD_without_case_class_array.count() + 
          " ~ insureDataMergedRDD_distinct.count: " + insureDataMergedRDD_distinct.count)
      
      //val duplicateRecords = insureDataMergedRDD_without_case_class_array.subtract(insureDataMergedRDD_distinct) - this is not working as the 
      // distince rdd also contains single row of duplicate RDD
      //val duplicateRecords = insureDataMergedRDD_without_case_class_array.groupBy(x => x).countByKey()
      //println("duplicateRecords.count: " + duplicateRecords.count)                        
      //duplicateRecords.foreach(println)
      // Only count is printed here and the actual duplicate values are found out with sql -- MRAJ_01
          
          
      //17. Increase the number of partitions in the above rdd to 8 and name it as insuredatarepart.
      val insureDataMergedRDD_Repart = insureDataMergedRDD.repartition(8)
      //insureDataMergedRDD_Repart.cache()
      
      // 18. Split the above RDD using the businessdate field into rdd_20191001 and rdd_ 20191002 based on the BusinessDate of 
      //2019-10-01 and 2019-10-02 respectively using Filter function.
      
      val insureDataMergedRDD_Repart_20191001 = insureDataMergedRDD_Repart.filter(x => x.BusinessDate == "2019-10-01")
      //insureDataMergedRDD_Repart_20191001.foreach(println)
      
      val insureDataMergedRDD_Repart_20191002 = insureDataMergedRDD_Repart.filter(x => x.BusinessDate == "2019-10-01" )
      //insureDataMergedRDD_Repart_20191002.foreach(println)
      """
      //19. Store the RDDs created in step 10, 13, 18 into HDFS locations.
      //RDD's saveAsTextFile can't overwrite the directory
      //hadoop fs -rmr /user/hduser/hackathon/sparkCore
      //hard coding the destination folder here instead of arguments since it is one time activity
      rejectedDataAnalyze.saveAsTextFile("hdfs://localhost:54310/user/hduser/hackathon/sparkCore/rejectedDataAnalysis")
      insureDataMergedRDD.saveAsTextFile("hdfs://localhost:54310/user/hduser/hackathon/sparkCore/insureDataMergedRDD")
      insureDataMergedRDD_Repart_20191001.saveAsTextFile("hdfs://localhost:54310/user/hduser/hackathon/sparkCore/insureDataMergedRDD/20191001")
      insureDataMergedRDD_Repart_20191002.saveAsTextFile("hdfs://localhost:54310/user/hduser/hackathon/sparkCore/insureDataMergedRDD/20191002")
      """
      
      // 20. Convert the RDD created in step 17 above into Dataframe namely insuredaterepartdf using toDF function
      val sqlc = sparksession.sqlContext
      import sqlc.implicits._
      val insureDataMergedRDD_Repart_DF = insureDataMergedRDD_Repart.toDF()
      //insureDataMergedRDD_Repart_DF.show(10, false)
      insureDataMergedRDD_Repart_DF.createOrReplaceTempView("insureDataMergedRDD_Repart_DF")
      //sqlc.sql("select distinct businessdate from insureDataMergedRDD_Repart_DF").show(false)
      """
      +------------+
      |businessdate|
      +------------+
      |02-10-2019  |
      |01-10-2019  |
      +------------+  
      """
      //MRAJ_01
      sqlc.sql("""select temp.*, count(1) from insureDataMergedRDD_Repart_DF temp 
      group by IssuerId,IssuerId2,BusinessDate,StateCode,SourceName,NetworkName,NetworkURL,custnum,MarketCoverage,DentalOnlyPlan
      having count(1) > 1""").show(false)
      //insureDataMergedRDD_Repart_DF.printSchema()
      //insure1RDD_05.toDF().show(10, false)
      //insure2RDD_05.toDF().show(10, false)
      
      """
      21. Create structuretype for all the columns as per the insuranceinfo1.csv with the columns such as 
      IssuerId,IssuerId2,BusinessDate,StateCode,SourceName,NetworkName,NetworkURL,custnum,MarketCoverage,DentalOnlyPlan
      Hint: Do it carefully without making typo mistakes. Fields issuerid, issuerid2 should be of IntegerType, 
      businessDate should be DateType and all other fields are StringType, ensure to import sql.types library  
      """
      import org.apache.spark.sql.types._
      val insureDataMergedRDD_Repart_DF_structClass = StructType(Array(StructField("IssuerId",IntegerType,false),
          StructField("IssuerId2",IntegerType,false),StructField("BusinessDate",DateType,false),StructField("StateCode",StringType,true),
          StructField("SourceName",StringType,true),StructField("NetworkName",StringType,true),StructField("NetworkURL",StringType,true),
          StructField("custnum",IntegerType,true),StructField("MarketCoverage",StringType,true),StructField("DentalOnlyPlan",StringType,true)))
      //defined one more structype to handle the date format issue in the second file
      val insureDataMergedRDD_Repart_DF_structClass_01 = StructType(Array(StructField("IssuerId",IntegerType,false),
          StructField("IssuerId2",IntegerType,false),StructField("BusinessDate",StringType,false),StructField("StateCode",StringType,true),
          StructField("SourceName",StringType,true),StructField("NetworkName",StringType,true),StructField("NetworkURL",StringType,true),
          StructField("custnum",IntegerType,true),StructField("MarketCoverage",StringType,true),StructField("DentalOnlyPlan",StringType,true)))    
          
      """
      ****
      22. Create dataframes using the csv module with option to escape ‘,’ accessing the insuranceinfo1.csv and insuranceinfo2.csv files and 
      remove the footer from both dataframes using header true, dropmalformed options and apply the schema of the structure type created in 
      the step 21.  
      """
          //yyyy-MM-dd is correct spark date format
      val  insure1RDD_01_DF = sqlc.read.option("delimiter",",").option("mode", "dropmalformed").option("header",true).//.option("distinct", true).
      schema(insureDataMergedRDD_Repart_DF_structClass).csv(args(0))
      //insure1RDD_01_DF.where("IssuerId = 70194").show(20, false)
      //insure1RDD_01_DF.rdd.coalesce(1).saveAsTextFile("file:///home/hduser/Hackathon/insure1RDD_01_DF_txt")
      //in the file only getting 401, but the below print is giving 403 
      //println(insure1RDD_01_DF.count())
      
      val  insure2RDD_01_DF = sqlc.read.option("mode", "dropmalformed").option("header",true).
      schema(insureDataMergedRDD_Repart_DF_structClass_01).csv(args(1))
      //insure2RDD_01_DF.show(20, false)
      import org.apache.spark.sql.functions._
      val insure2RDD_02_DF = insure2RDD_01_DF.select(col("IssuerId"),col("IssuerId2"),to_date(col("BusinessDate"),"dd-MM-yyyy").as("BusinessDate"),
          col("StateCode"),col("SourceName"),col("NetworkName"),col("NetworkURL"),col("custnum"),col("MarketCoverage"),col("DentalOnlyPlan"))
      //insure2RDD_02_DF.show(20,true)
      //println(insure2RDD_02_DF.count())
      
      val insureRDDMerged_DF = insure1RDD_01_DF.union(insure2RDD_02_DF)
      println(insureRDDMerged_DF.count())//3737
      val insureRDDMerged_DF_Distinct = insureRDDMerged_DF.dropDuplicates()
      println(insureRDDMerged_DF_Distinct.count())//3291
      
      val insureRDD_Multiple = sqlc.read.option("mode", "dropmalformed").option("header",true).
      schema(insureDataMergedRDD_Repart_DF_structClass_01).csv(args(0),args(1))
      
      val insureRDD_Multiple_Distinct = insureRDD_Multiple.dropDuplicates()
      println(insureRDD_Multiple_Distinct.count)//3291
      
      """
      23. Apply the below DSL functions in the DFs created in step 22.
      a. Rename the fields StateCode and SourceName as stcd and srcnm respectively.
      b. Concat IssuerId,IssuerId2 as issueridcomposite and make it as a new field
      Hint : Cast to string and concat.
      c. Remove DentalOnlyPlan column
      d. Add columns that should show the current system date and timestamp with the fields name of sysdt and systs respectively.
      Try the below usecases also seperately:
      i.   Identify all the column names and store in an array variable – use columns function.
      ii.  Identify all columns with datatype and store in an array variable – use dtypes function.
      iii. Identify all integer columns alone and store in an array variable.
      iv.  Select only the integer columns identified in the above statement and show 10 records in the screen.  
      """
      
      val insureRDDMerged_DF_Distinct_Rename = insureRDDMerged_DF_Distinct.
      select(concat(col("IssuerId".toString()),col("IssuerId2".toString())).as("issuerIdComposite"),
          col("IssuerId").as("IssuerId"),col("IssuerId2").as("IssuerId2"),col("BusinessDate"),
          col("StateCode").as("stcd"),col("SourceName").as("srcnm"),col("NetworkName"),col("NetworkURL"),col("custnum").as("custnum"),
          col("MarketCoverage"), current_date().as("sysdt"), current_timestamp().as("systs"))
          
      val columnNames = insureRDDMerged_DF_Distinct_Rename.columns
      val colDatTypes = insureRDDMerged_DF_Distinct_Rename.dtypes//.mkString(",")
      //println(colDatTypes)
      val intColumns_Types = insureRDDMerged_DF_Distinct_Rename.dtypes.filter(x => x._2.toUpperCase() == "INTEGERTYPE")//.mkString(",")
      //println(intColumns)
      //val intColumns = intColumns_Types.map(x => "col("+x._1+")").mkString(",")
      
      val intColumns = intColumns_Types.map(x => col(x._1))
      //println(intColumns)
      //insureRDDMerged_DF_Distinct_Rename.select("IssuerId","IssuerId2","custnum").show(2, false)
      //https://sparkbyexamples.com/spark/spark-select-columns-from-dataframe/
      val insureRDDMerged_DF_Distinct_Rename_CustNum = insureRDDMerged_DF_Distinct_Rename.select(intColumns.map(x => x):_*)
      insureRDDMerged_DF_Distinct_Rename_CustNum.show(10, false)
      """
      +--------+---------+-------+
      |IssuerId|IssuerId2|custnum|
      +--------+---------+-------+
      |97725   |97725    |14     |
      |85320   |85320    |35     |
      |90264   |90264    |14     |
      |67202   |67202    |14     |
      |90453   |90453    |13     |
      |59928   |59928    |13     |
      |50022   |50022    |14     |
      |44580   |44580    |13     |
      |66599   |66599    |14     |
      |50221   |50221    |13     |
      +--------+---------+-------+
      """
      
      
      """
      24. Take the DF created in step 23.d and Remove the rows contains null in any one of the field and 
      count the number of rows which contains all columns with some value.  
      """
      val insureRDDMerged_DF_Distinct_Rename_Not_null = insureRDDMerged_DF_Distinct_Rename.na.drop("any")
      println(insureRDDMerged_DF_Distinct_Rename_Not_null.count()) //1407
      
      //val insureRDDMerged_DF_Distinct_Rename_Not_null_custnum = insureRDDMerged_DF_Distinct_Rename.drop(col("custnum"))
      //println(insureRDDMerged_DF_Distinct_Rename_Not_null_custnum.count()) //3219
      
      """
      25. Custom Method creation: Create a package (org.inceptez.hack), class (allmethods), method (remspecialchar)
      Hint: First create the function/method directly and then later add inside pkg, class etc..
      a. Method should take 1 string argument and 1 return of type string
      b. Method should remove all special characters and numbers 0 to 9 - ? , / _ ( ) [ ] Hint: Use replaceAll function, 
      usage of [] symbol should use \\ escape sequence.
      c. For eg. If I pass to the method value as Pathway - 2X (with dental) it has to return Pathway X with dental as output. 
      
      26. Import the package, instantiate the class and register the method generated in step 25 as a udf for invoking in the DSL function  
      """
      import org.inceptez.hack._
      val hackObject = new allmethods
      val udfReplaceSpecialChar = udf(hackObject.remspecialchar _)
      
      // 27. Call the above udf in the DSL by passing NetworkName column as an argument to get the special characters removed DF.
      val insureRDDMerged_DF_Spl_char_removed = insureRDDMerged_DF_Distinct_Rename_Not_null.//where("networkName like '%Humana%'").
      select(col("issuerIdComposite"),
          col("IssuerId").as("IssuerId"),col("IssuerId2").as("IssuerId2"),col("BusinessDate"),
          col("stcd"),col("srcnm"),col("NetworkName"),udfReplaceSpecialChar(col("NetworkName")).as("NetworkNameEdited"),col("NetworkURL"),col("custnum").as("custnum"),
          col("MarketCoverage"), col("sysdt"), col("systs"))
      //insureRDDMerged_DF_Spl_char_removed.show(20, false)  
      
      //Harcoding the paths here as there are in overwrite mode for DF
          
      //28. Save the DF generated in step 27 in JSON into HDFS with overwrite option.    
      insureRDDMerged_DF_Spl_char_removed.coalesce(1).write.mode("overwrite").json("hdfs://localhost:54310/user/hduser/hackathon/insureRDD_DF_JSON")
      
      //29. Save the DF generated in step 27 into CSV format with header name as per the DF and delimited by ~ into HDFS with overwrite option.
      insureRDDMerged_DF_Spl_char_removed.coalesce(1).write.mode("overwrite").option("delimiter", "~").
      option("header",true).csv("hdfs://localhost:54310/user/hduser/hackathon/insureRDD_DF_CSV")
      
      //30. Save the DF generated in step 27 into hive external table and append the data without overwriting it.
      //import org.apache.spark.sql.hive.HiveContext
      
      //val hiveContext = new HiveContext(sc)
      
      //sc.stop()
      // Dataframes can't be shifted between the spark contexts and so it is good to create the below spark session in the beginning itself
      //and using the spark and sql context created as part of it
      """
      val sparksession = SparkSession.builder().appName("Inceptez Hackathon").master("local[*]").
                         config("spark.eventLog.dir","file:///tmp/spark-events").
                         config("spark.history.fs.logDirectory","file:///tmp/spark-events").
                         config("spark.eventLog.enabled","true").
                         config("hive.metastore.uris","thrift://127.0.0.1:9083").
                         config("spark.sql.warehouse.dir","hdfs://127.0.0.1:54310/user/hive/warehouse").
                         config("spark.sql.shuffle.partitions",10).
                         config("spark.sql.crossJoin.enabled","true").
                         enableHiveSupport().getOrCreate();
      """                   
      //hive table name - hackathon.insureRDDMerged_DF_Spl_char_removed
      sparksession.sql("drop database if exists "+args(2)+" cascade")
      sparksession.sql("create database if not exists "+args(2))
      insureRDDMerged_DF_Spl_char_removed.show(20, false)
      //sparksession.catalog.listDatabases    
      //sparksession.sql("show databases")
      insureRDDMerged_DF_Spl_char_removed.coalesce(1).write.mode("append").saveAsTable(args(2)+"."+args(3))
      
      //31. Load the file3 (custs_states.csv) from the HDFS location, using textfile API in an RDD custstates, this file contains 2 
      //type of data one with 5 columns contains customer master info and other data with statecode and description of 2 columns.
      
      //hadoop fs -put -f /home/hduser/Hackathon/custs_states.csv /user/hduser/hackathon
      
      val custStatesRDD = sc.textFile(args(4), 1)
      //custStatesRDD.foreach(println)
      
      //32. Split the above data into 2 RDDs, first RDD namely custfilter should be loaded only with 5 columns data 
      //and second RDD namely statesfilter should be only loaded with 2 columns data.
      
      val custDataRDD = custStatesRDD.map(x => x.split(",")).filter(x => x.length > 2)
      val statesDataRDD = custStatesRDD.map(x => x.split(",")).filter(x => x.length == 2)
      
      //println(custDataRDD.count())
      //println(statesDataRDD.count())
      
      val broadCast_states = statesDataRDD.collect() // broadcasting this RDD as this is like a static data
      sc.broadcast(broadCast_states)
      
      //33. Load the file3 (custs_states.csv) from the HDFS location, using CSV Module in a DF custstatesdf, this file contains 2 
      //type of data one with 5 columns contains customer master info and other data with statecode and description of 2 columns.
      
      val custStates_DF = sparksession.read.option("delimiter", ",").option("mode", "permissive").option("header", false).
      csv(args(4))
      custStates_DF.printSchema()
      """
      34. Split the above data into 2 DFs, first DF namely custfilterdf should be loaded only with 5 columns data and second DF namely 
      statesfilterdf should be only loaded with 2 columns data.
      Hint: Use filter/where DSL function to check isnull or isnotnull to achieve the above functionality then rename, change the type 
      and drop columns in the above 2 DFs accordingly.  
      """
      
      val custData_DF = custStates_DF.where("_c2 is not null").select(col("_c0").as("customerID"), col("_c1").as("customerFirstName"),
          col("_c2").as("customerLastName"), col("_c3").as("customerAge"),col("_c4").as("profession"))
      val statesData_DF = custStates_DF.where("_c2 is null").select(col("_c0").as("stateCode"), col("_c1").as("stateName"))   
      //println(custData_DF.count())
      //println(statesData_DF.count())
      
      //35. Register the above step 34 DFs as temporary views as custview and statesview.
      //36. Register the DF generated in step 23.d as a tempview namely insureview
      custData_DF.createOrReplaceTempView("custData_DF_View")
      statesData_DF.createOrReplaceTempView("statesData_DF_View")
      insureRDDMerged_DF_Distinct_Rename.createOrReplaceTempView("insureRDDMerged_DF_View")
      
      //37. Import the package, instantiate the class and Register the method created in step 25 in the name of 
      //remspecialcharudf using spark udf registration.
      sparksession.udf.register("udfReplaceSpecialChar", udfReplaceSpecialChar)
      //sparksession.udf.
      
      """
      38. Write an SQL query with the below processing – set the spark.sql.shuffle.partitions to 4
      a. Pass NetworkName to remspecialcharudf and get the new column called cleannetworkname
      b. Add current date, current timestamp fields as curdt and curts.
      c. Extract the year and month from the businessdate field and get it as 2 new fields called yr,mth respectively.
      d. Extract from the protocol either http/https from the NetworkURL column, if http then print http non secured if 
      https then secured else no protocol found then display noprotocol. For Eg: if http://www2.dentemax.com/ then show http non 
      secured else if https://www2.dentemax.com/ then http secured else if www.bridgespanhealth.com then show as no protocol store in a 
      column called protocol.
      e. Display all the columns from insureview including the columns derived from above a, b, c, d steps with statedesc column from 
      statesview with age,profession column from custview . Do an Inner Join of insureview with statesview using stcd=stated and join 
      insureview with custview using custnum=custid.  
      """
      sparksession.conf.set("spark.sql.shuffle.partitions", 4)
      val custInsureData_DF = sparksession.sql("""
  	  select 
  	  insure_view.issuerIdComposite as issuerIdComposite,
      insure_view.IssuerId         as IssuerId,
      insure_view.IssuerId2        as IssuerId2,
      insure_view.BusinessDate     as BusinessDate,
      insure_view.stcd             as stcd,
      insure_view.srcnm            as srcnm,
      insure_view.NetworkName      as NetworkName,                                      
      udfReplaceSpecialChar(insure_view.NetworkName) as NetworkNameEdited,                                      
      insure_view.NetworkURL       as NetworkURL,                                                                                              
      insure_view.custnum          as custnum,
      insure_view.MarketCoverage   as MarketCoverage, 
      insure_view.sysdt  as curdt          ,
      insure_view.systs  as curts          ,
      extract(year from insure_view.BusinessDate)  as year,
      extract(Month from insure_view.BusinessDate)  as month,
      (case when upper(substr(insure_view.NetworkURL,1,instr(insure_view.NetworkURL,":") - 1)) = 'HTTPS' then 'https'
            when upper(substr(insure_view.NetworkURL,1,instr(insure_view.NetworkURL,":") - 1)) = 'HTTP' then 'http'
            else 'No Protocol' end) as protocol,
      (case when upper(substr(insure_view.NetworkURL,1,instr(insure_view.NetworkURL,":") - 1)) = 'HTTPS' then 'Secured'
            when upper(substr(insure_view.NetworkURL,1,instr(insure_view.NetworkURL,":") - 1)) = 'HTTP' then 'Not Secured'
            else 'No Protocol' end) as securedOrNot,    
      state_view.stateName as stateName,
      cust_view.customerAge as age,
      cust_view.profession as profession
  	  from insureRDDMerged_DF_View insure_view, custData_DF_View cust_view, statesData_DF_View state_view
  	  where  insure_view.custnum =  cust_view.customerID
  	  and    insure_view.stcd    =  state_view.stateCode""").coalesce(1)//.show(20, false)
  	  
  	  //39. Store the above selected Dataframe in Parquet formats in a HDFS location as a single file.
  	  //Spark default format is parquet with snappy compression
  	  custInsureData_DF.coalesce(1).write.mode("overwrite").//format("parquet").
  	  save("hdfs://127.0.0.1:54310/user/hduser/hackathon/custInsureData_DF")
  	  //file got saved with ORC and snappy complression
  	  custInsureData_DF.coalesce(1).write.mode("overwrite").format("orc").save("hdfs://127.0.0.1:54310/user/hduser/hackathon/custInsureData_DF_text")
  	  
  	  //Text is not supported for writing from spark DF. If needed convert it to RDD and give saveastextfile
  	  
  	  """
  	  40. Write an SQL query to identify average age, count group by statedesc, protocol, profession including a seqno column 
  	  added which should have running sequence number partitioned based on protocol and ordered based on count descending and display 
  	  the profession whose second highest average age of a given state and protocol.
      For eg.
      Seqno,Avgage,count,statedesc,protocol,profession
      1,48.4,10000, Alabama,http,Pilot 2,72.3,300, Colorado,http,Economist
      1,48.4,3000, Atlanta,https,Health worker 2,72.3,2000, New Jersey,https,Economist  
      
      confudes with the requirement
  	  """
  	  custInsureData_DF.createOrReplaceTempView("custInsureData_DF_View")
  	  sparksession.sql("""select v1.avg_Age, v1.count_s, v1.stateName, v1.protocol, v1.profession from (
  	    select row_number() over(partition by temp_view.protocol order by temp_view.count_s desc) as sequence,
  	    temp_view.avg_Age as avg_Age, temp_view.count_s as count_s, temp_view.stateName as stateName, 
  	    temp_view.protocol as protocol, temp_view.profession as profession
  	    from
  	    (select avg(a.age) as avg_Age, count(1) as count_s, a.stateName as stateName, a.protocol as protocol, 
  	    a.profession as profession
  	    from custInsureData_DF_View a
  	    group by a.stateName, a.protocol, a.profession) temp_view) v1
  	    where sequence = 2""").show(20, false)
  	    
  	  //41. Store the DF generated in step 39 into MYSQL table insureaggregated.
  	   //WriteToDB trait of datalake pjt is extended to achive functionalities
  	    //val connectionFile = "hdfs:///127.0.0.1:54310/user/hduser/hackathon/connection.prop"
  	    val connectionFile = "/home/hduser/projects/project3/retailordersspark/connection.prop"
  	    //def writeRdbmsTable(df:DataFrame,DatabaseName:String, TableName:String, PartitionColumn:String,ConnectionFile:String,WriteMode:String):Boolean
  	    val tableWriteFlag = writeRdbmsTable(custInsureData_DF, "custInsure", "custInsureData_DF", null, s"$connectionFile", "overwrite")
  	    println("tableWriteFlag: " + tableWriteFlag)
  	    
  	  """
  	  42. Try Package the code using maven install, take the lean and fat jar and try submit with driver memory of 512M, 
  	  number of executors as 4, executor memory as 1GB and executor cores with 2 cores. Try Dynamic allocation also.  
  	  """  
    }
    catch
    {
      case a: java.io.NotSerializableException => println("The class does not extends java.io.serializable")
    }
    finally
    {
      sc.stop()
    }
  }
}
