package hackathon
import org.apache.spark.sql.SparkSession
object mainObjectSQL {
  def main(args:Array[String])
  {
    val sparksession = SparkSession.builder().appName("Inceptez Hackathon").master("local[*]").
                       config("spark.eventLog.dir","file:///tmp/spark-events").
                       config("spark.history.fs.logDirectory","file:///tmp/spark-events").
                       config("spark.eventLog.enabled","true").
                       config("hive.metastore.uris","thrift://127.0.0.1:9083").
                       config("spark.sql.warehouse.dir","hdfs://127.0.0.1:54310/user/hive/warehouse").
                       config("spark.sql.shuffle.partitions",10).
                       config("spark.sql.crossJoin.enabled","true").
                       enableHiveSupport().getOrCreate();
    //hive table name - hackathon.insureRDDMerged_DF_Spl_char_removed
    sparksession.sql("drop database if exists hackathon cascade")
    sparksession.sql("create database if not exists hackathon")
    
    //insureRDDMerged_DF_Spl_char_removed.write.mode("append").saveAsTable("hackathon.insureRDDMerged_DF_Spl_char_removed")
  }
}