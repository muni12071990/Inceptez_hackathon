package sparkCore

import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import java.text.SimpleDateFormat
import java.util.Date

case class Employee(empno:Integer, ename:String, designation:String, manager:String, hire_date:Date, hire_date_string:String, sal:String , 
                    deptno:Integer)

class rddcreation(sc:SparkContext, path:String) 
{
  def rddFrompath(path:String):RDD[String] =
  {
    val retRDD = sc.textFile(path, 1)
    return retRDD
  }
  
  def dateReplace(inputString:String):String = 
  {
    var retDate = ""
    if (!inputString.substring(0,4).contains("-"))
    {
      if (inputString.count(_ == '-') == 2) // checking if it contains 2 "-"
      {
        retDate = inputString.substring(8,10)+"-"+inputString.substring(5,7)+"-"+inputString.substring(0,4)
      }
    }
    return retDate
  }
}


object sparkCoreUnderstanding {
  def main(args:Array[String])
  {
    val dateFormat = new SimpleDateFormat("MM/dd/yyyy")
    val conf = new SparkConf().setMaster("local[2]").setAppName("Understanding Spark Core")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val objrddcreation = new rddcreation(sc, args(0))
    val retRDD = objrddcreation.rddFrompath(args(0))
    //retRDD.foreach(println)
    val rddNonEmpty = retRDD.map(lines => 
                                {
                                  val line = lines.split(",")
                                  if (line(0).toUpperCase() == line(0))
                                  {
                                    Employee(line(0).toInt, line(1), line(2), line(3), dateFormat.parse(line(4)), line(4), line(5), 
                                             line(6).toInt)
                                  }
                                }
                                )
    //println(rddNonEmpty.count())
    val rddNonEmptycoll = rddNonEmpty.collect
    rddNonEmptycoll.foreach(println)
    val insure1RDD = sc.textFile("hdfs://127.0.0.1:54310/user/hduser/hackathon/insuranceinfo1.csv", 2)
    println(insure1RDD.count())
  }
}
