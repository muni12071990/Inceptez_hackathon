package hackathon

object testFunction {
  def main(args:Array[String]) 
  {
    val reUsableObj = new reUsable
    var temp = reUsableObj.functionInfun("10-02-2020")
    println(temp)
    val obj1 = new org.inceptez.hack.allmethods
    temp  = obj1.remspecialchar("abc189[]defg96hij")
    println(temp)
  }
}