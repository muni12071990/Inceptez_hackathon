package hackathon
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
class reUsable extends java.io.Serializable {

  def rddFrompath(sc:SparkContext,path:String):RDD[String] =
  {
    val retRDD = sc.textFile(path, 1)
    return retRDD
  }
  
  def dateReplace(inputString:String):String = 
  {
    var retDate = ""
    if (inputString.substring(0,4).contains("-"))
    {
      if (inputString.count(_ == '-') == 2) // checking if it contains 2 "-"
      {
        //01-10-2019
        retDate = inputString.substring(6,10)+"-"+inputString.substring(3,5)+"-"+inputString.substring(0,2)
      }
    }
    else
      retDate = inputString
    return retDate
  }
  
  def functionInfun(dateReplace1:String):String = 
  {
    var retTemp = ""
    retTemp = dateReplace(dateReplace1)
    return retTemp
  }
}