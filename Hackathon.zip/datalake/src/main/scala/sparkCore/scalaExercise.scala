package sparkCore

import java.io.IOException

class greatestNumber
{
  def greatesNumberMethod(input:Array[Int]):Int = 
  {
    val sortedInput = input.sorted(Ordering.Int.reverse)
    return sortedInput(0)
  }
  
  def courseFees(courseName:String):Long = 
  {
    try
    {
      var courseFees = 0
      val courseFeesMap = Map("BIGDATA"->150 , "SPARK"->200, "ORACLE"->50, "JAVA"-> 50)
      """val retValue = courseFeesMap(courseName.toUpperCase()) match
      {
        case 1 => 0
        case _ => courseFeesMap(courseName.toUpperCase())
      }"""
      if (courseFeesMap.contains(courseName.toUpperCase()))
      {
        println("Inside IF loop")
        courseFees = courseFeesMap(courseName.toUpperCase())
      }
      println("courseFees: " + courseFees)
      return courseFees
    }
    catch
    {
      case a:IOException => 0 
    }
  }
  
  def palindrom(inputString:String):String = 
  {
    var retString = "'" + inputString + "' is NOT a palindrom"
    val tempVariable = inputString.reverse
    if (inputString.toUpperCase() == tempVariable.toUpperCase())
    {
      retString = "'" + inputString + "' is a POSITIVE palindrom"
    }
    return retString
  }
  
  def printEvenOdd(in1:Long, in2:Long) = 
  {
    var evenArray:Array[Long] = Array()
    var oddArray:Array[Long] = Array()
    if (in2 > in1)
    {
      for(x<-in1 to in2 by 1)
      {
        if (x%2 == 0)
          evenArray = evenArray :+ x        
        else
          oddArray = oddArray :+ x
      }
      evenArray.foreach(println)
      oddArray.foreach(println)
    }
    else if (in1 == in2)
      println("Both numbers are equal")
    else
      println("Please reverse the numbers")
  }
  
  def forLoopIncrementer(fromNumber:Long, toNumber:Long, incNumber:Int) = 
  {
    var retString:String = ""
    if (toNumber > fromNumber)
    {
      for (x <- fromNumber to toNumber by incNumber)
      {  
        retString = retString + "," +  x
      }  
      println(retString.replaceFirst(",", " ").trim())  
    }
  }
  
  def numLoop(inNum:Long, countNum:Int) = 
  {
    var retNumber:Long = 0
    var varcountNum = countNum
    while (varcountNum >= 0)
    {
      println(varcountNum + ":" + retNumber)
      retNumber = retNumber + (inNum * inNum)
      varcountNum = varcountNum - 1
    }
    println("Result: " + retNumber)
  }
  
  def calculator(inNum1:Int, inNum2:Int, operation:String) = 
  {
    var resultReturn:Any = 0
    //Possible operation: Add/Addition, Sub/Subtraction, Mul/Multiply/Multiplication, div/Divide/Division, modulus
    if (operation.toUpperCase() == "ADD" || operation.toUpperCase() == "ADDITION")
      resultReturn = inNum1 + inNum2
    else if (operation.toUpperCase() == "SUB" || operation.toUpperCase() == "SUBTRACTION")
      resultReturn = inNum1 - inNum2
    else if (operation.toUpperCase() == "MUL" || operation.toUpperCase() == "MULTIPLY" || operation.toUpperCase() == "MULTIPLICATION")
      resultReturn = inNum1 * inNum2
    else if (operation.toUpperCase() == "DIV" || operation.toUpperCase() == "DIVIDE" || operation.toUpperCase() == "DIVISION")
      resultReturn = (inNum1/inNum2).toFloat
      
    println("result of " + operation + " between " + inNum1 + " and " + inNum2 + " is " + resultReturn)  
  }
  
  def arrIterate(num1:Int, num2:Int):Array[Int] = 
  {
    var arr1:Array[Int] = Array()
    for(x<-1 to num1 by 1)
      arr1 = arr1 :+ num2
    return arr1
  }
  
  def hackerRank(inNum:Int, arr:Array[Int]):Array[Any] = 
  {
    var emptyArray:Array[Any] = Array()
    val emptyArrayTest = arr.map(x=>arrIterate(inNum,x))
    emptyArrayTest.map(x=>x.toTraversable).foreach(println)
    emptyArrayTest.copyToArray(emptyArray)
    return emptyArray
  }
  
  def hackerRank1(inNum:Int, arr:Array[Int]):Array[Int] = 
  {
    var emptyArray:Array[Int] = Array()
    for (x <- arr)
      for (y<- 1 to inNum by 1)
        emptyArray = emptyArray :+ x
    return emptyArray    
  }
}

object scalaExercise {
  def main(args:Array[String])
  {
    val objOfClass = new greatestNumber
    //val greatedNum = objOfClass.greatesNumberMethod(Array(10, 9,7,86,5,2,4,8,9,6,15,19))
    //println(greatedNum)
    //println(objOfClass.courseFees("bigData"))
    //println(objOfClass.palindrom("Malayalam"))
    //objOfClass.printEvenOdd(1, 10)
    //objOfClass.forLoopIncrementer(1, 50, 4)
    //objOfClass.numLoop(4, 3)
    //objOfClass.calculator(10, 2, "Mul")
    //val retArray = objOfClass.arrIterate(3, 2)
    //retArray.foreach(println)
    //val retObj = objOfClass.hackerRank(2,Array(2,1))
    //retObj.foreach(println)
    val retObj1 = objOfClass.hackerRank1(2,Array(2,1))
    retObj1.foreach(println)
  }
}
