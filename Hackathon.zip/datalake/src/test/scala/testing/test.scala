package testing

object test {
  def main(args:Array[String])
  {
    println("Testing the apps")
  }
}