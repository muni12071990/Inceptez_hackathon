package hackathon_streaming
import org.apache.spark.sql.SparkSession
import java.util.Properties
import java.io.FileInputStream
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.clients._
import org.apache.kafka.server._
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.HasOffsetRanges
import org.apache.spark.sql.SaveMode
import org.elasticsearch.spark.sql._
import org.apache.spark.streaming.kafka010.CanCommitOffsets

object sparkjson {
  def main(args:Array[String])
  {
    //Reading all the values from prop file
    val conn = new Properties()
    //args(0) = /home/hduser/Hackathon/connection_streaming.prop
    val prop = new FileInputStream(args(0))
    conn.load(prop)
    
    val sparklog = conn.getProperty("sparklog")
    val hivemetastore = conn.getProperty("hivemetastore")
    val sqlwarehouse = conn.getProperty("sqlwarehouse")
    val esnode = conn.getProperty("esnode")
    val esport = conn.getProperty("esport")
    
    val Seconds_time = conn.getProperty("Seconds_time")
    val kafkatopics = conn.getProperty("kafkatopics")//should be comma separated in properties file
    val zookeeperservers = conn.getProperty("zookeeperservers")
    val groupid = conn.getProperty("groupid")
    val offset = conn.getProperty("offset")
    
    val sparksession = SparkSession.builder().appName("Hackathon Streaming").master("local[*]").
                       config("spark.history.fs.logDirectory",s"$sparklog").
                       config("spark.eventlog.dir",s"$sparklog").
                       config("spark.events.enabled","true").
                       config("hive.metastore.uris",s"$hivemetastore").
                       config("spark.sql.warehouse.dir",s"$sqlwarehouse"). //this is namenode URL. we can use the particular HIVE datanode/HIVE installed also
                       config("spark.sql.shuffle.partition",10).
                       config("spark.es.nodes",s"$esnode").
                       config("spark.es.port",esport).
                       config("es.nodes.wan.only","true").
                       enableHiveSupport().getOrCreate();
    
   
    //println(sparksession.sparkContext)
    sparksession.sparkContext.setLogLevel("ERROR");
    val streaming = new StreamingContext(sparksession.sparkContext,Seconds(Seconds_time.toLong))
        
    val kafkatopicsArray = kafkatopics.split(",")
    
    val kafkapramas = Map[String, Object](
                        "bootstrap.servers"   ->   s"$zookeeperservers",
                        "key.deserializer"    ->   classOf[StringDeserializer],
                        "value.deserializer"  ->   classOf[StringDeserializer],
                        "group.id"            ->   s"$groupid",
                        "auto.offset.reset"   ->   s"$offset",
                        "enable.auto.commit"  ->   (false:java.lang.Boolean)
                      )
    //println("kafkapramas.values" +kafkapramas.keys+ " ~ " + kafkapramas.values)                                            
    val discreatestream = KafkaUtils.createDirectStream[String, String](streaming, PreferConsistent, Subscribe[String,String] (kafkatopicsArray, kafkapramas))
    
    try
    {
      //println("discreatestream.count(): " + discreatestream.count().toString())
      discreatestream.foreachRDD{
        iterateRDD => 
        val kafkaoffsets = iterateRDD.asInstanceOf[HasOffsetRanges].offsetRanges
        //println("into try block")
         println("Printing offset ranges: ")
         kafkaoffsets.foreach(println)
         if (!iterateRDD.isEmpty())
         {
           import sparksession.sqlContext.implicits._
           import org.apache.spark.sql.Column
           val jsonRDD = iterateRDD.map(x => x.value())
           val jsonRDD_DF = sparksession.sqlContext.read.option("multiline", true).option("mode", "DROPMALFORMED").json(jsonRDD)
           println("jsonRDD_DF.count(): " + jsonRDD_DF.count())
           /*
            * root
 |-- info: struct (nullable = true)
 |    |-- page: long (nullable = true)
 |    |-- results: long (nullable = true)
 |    |-- seed: string (nullable = true)
 |    |-- version: string (nullable = true)
 |-- results: array (nullable = true)
 |    |-- element: struct (containsNull = true)
 |    |    |-- cell: string (nullable = true)
 |    |    |-- dob: struct (nullable = true)
 |    |    |    |-- age: long (nullable = true)
 |    |    |    |-- date: string (nullable = true)
 |    |    |-- email: string (nullable = true)
 |    |    |-- gender: string (nullable = true)
 |    |    |-- id: struct (nullable = true)
 |    |    |    |-- name: string (nullable = true)
 |    |    |    |-- value: string (nullable = true)
 |    |    |-- location: struct (nullable = true)
 |    |    |    |-- city: string (nullable = true)
 |    |    |    |-- coordinates: struct (nullable = true)
 |    |    |    |    |-- latitude: string (nullable = true)
 |    |    |    |    |-- longitude: string (nullable = true)
 |    |    |    |-- country: string (nullable = true)
 |    |    |    |-- postcode: string (nullable = true)
 |    |    |    |-- state: string (nullable = true)
 |    |    |    |-- street: struct (nullable = true)
 |    |    |    |    |-- name: string (nullable = true)
 |    |    |    |    |-- number: long (nullable = true)
 |    |    |    |-- timezone: struct (nullable = true)
 |    |    |    |    |-- description: string (nullable = true)
 |    |    |    |    |-- offset: string (nullable = true)
 |    |    |-- login: struct (nullable = true)
 |    |    |    |-- md5: string (nullable = true)
 |    |    |    |-- password: string (nullable = true)
 |    |    |    |-- salt: string (nullable = true)
 |    |    |    |-- sha1: string (nullable = true)
 |    |    |    |-- sha256: string (nullable = true)
 |    |    |    |-- username: string (nullable = true)
 |    |    |    |-- uuid: string (nullable = true)
 |    |    |-- name: struct (nullable = true)
 |    |    |    |-- first: string (nullable = true)
 |    |    |    |-- last: string (nullable = true)
 |    |    |    |-- title: string (nullable = true)
 |    |    |-- nat: string (nullable = true)
 |    |    |-- phone: string (nullable = true)
 |    |    |-- picture: struct (nullable = true)
 |    |    |    |-- large: string (nullable = true)
 |    |    |    |-- medium: string (nullable = true)
 |    |    |    |-- thumbnail: string (nullable = true)
 |    |    |-- registered: struct (nullable = true)
 |    |    |    |-- age: long (nullable = true)
 |    |    |    |-- date: string (nullable = true)
            * */
           // udfReplaceSpecialChar is registered as a function in HIVE
           // floor(datediff(current_date(),to_date(substr(res.dob.date,1,10)))/365) as computedAge -> age = computedAge will always be true
           //firstName which was in not in English was not mapped to correct colun when placed near numeric field. So placed
           //such types of column near the string fields
           jsonRDD_DF.createOrReplaceTempView("jsonRDD_DF")
           //jsonRDD_DF.createOrReplaceGlobalTempView("jsonRDD_DF_Global")
           
           val jsonRDD_DF_01 = sparksession.sql("""
             select username as custid, replace(default.udfreplacespecialchar(cell)," ","") as cell, firstName, gender,age,
             dobdt, (case when age = computedAge then 'Valid' else 'Invalid' end) as ageflag, 
             email, uscity, state, country,  
             concat(latitude,',',longitude) as coordinates, 
             curdt, curts, page
             from (select explode(results) as res, 
             info.page as page,
             res.cell as cell,
              res.name.first as firstName,
              res.gender as gender,
              res.dob.age as age,
              substr(res.dob.date,1,10) as dobdt,
              round(datediff(current_date(),to_date(substr(res.dob.date,1,10)))/365) as computedAge,
              res.email as email,
              res.location.city as uscity,
              res.location.coordinates.latitude as latitude,
              res.location.coordinates.longitude as longitude,
              res.location.country as country,
              res.location.state as state,
              res.location.timezone as timezone,
              res.login.username as username,
              current_date as curdt,
              current_timestamp as curts
              from jsonRDD_DF) where age > 25""")
              
          jsonRDD_DF_01.saveToEs("hackathon_streaming_sparkjson/custvisit", Map("es.mapping.id" -> "custid"))
          
          //Committing the offset values to Kafka
                discreatestream.asInstanceOf[CanCommitOffsets].commitAsync(kafkaoffsets)
                
                println("completed after committing the offsets to Kafka")
           
         }
         else
         {
           println("this time the records are empty")
         }
      
      }
    }
    catch
    {
      case exception1: java.lang.NullPointerException => {
        println("Null pointer exception") }
    }
    
    streaming.start()
    streaming.awaitTermination()
    // Findout how to stop the application for releases
  }
  
}