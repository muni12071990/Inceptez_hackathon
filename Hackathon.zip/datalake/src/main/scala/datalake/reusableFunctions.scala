package datalake

class reusableFunctions extends java.io.Serializable{
  def udf_concat(input_01:String, input_02:String):String = 
  {
    val output = input_01 + " " + input_02
    return output
  }
}